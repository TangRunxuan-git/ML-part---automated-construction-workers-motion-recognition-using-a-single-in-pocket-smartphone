import os
import numpy as np
import pandas as pd
import torch
from sklearn.ensemble import IsolationForest
from sklearn.tree import DecisionTreeClassifier
from sklearn.utils import resample
from sklearn.model_selection import train_test_split, GridSearchCV, RandomizedSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, ExtraTreesClassifier, BaggingClassifier, \
    StackingClassifier
from lightgbm import LGBMClassifier
from catboost import CatBoostClassifier
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
import xgboost as xgb
from imblearn.over_sampling import SMOTE
# 假设config模块中定义了相关配置
class Config:
    DATA_PATH = r'D:\传感器\data\all_data1.csv'
    MODEL_SAVE_DIR = r'D:\传感器\weight'


config = Config()


def process_sliding_window(X_data, y_data, window_seconds, window_overlapping):
    sample_hz = 50  # 传感器采样频率
    window_size = int(window_seconds * sample_hz)  # 窗口大小（采样点数）
    step_size = int(window_size * (1 - window_overlapping))  # 步长，考虑到窗口重叠率
    windows = []
    labels = []
    i = 0
    while i + window_size <= X_data.shape[0]:  # 遍历数据
        if (X_data[i + window_size - 1, 0] - X_data[i, 0]) <= 2 * window_seconds * 1e9:
            windows.append(X_data[i:i + window_size, :])
            labels.append(y_data[i + window_size - 1])
            i += step_size  # 移动到下一个窗口
        else:
            i += 1  # 数据不连续，跳到下一个点
    windows = np.array(windows)
    labels = np.array(labels)
    return windows, labels


# 读取数据
data = pd.read_csv(config.DATA_PATH)

# 使用孤立森林删除离群值
isolation_forest = IsolationForest(contamination=0.01)
outliers = isolation_forest.fit_predict(data.iloc[:, 1:])  # 假设第1列是非数值列
data['outlier'] = outliers

# 过滤掉离群点
data_clean = data[data['outlier'] == 1]
data_clean = data_clean.drop(columns=['outlier'])

# 打印删除前后的样本数量
print(f"Original data size: {data.shape[0]}")
print(f"Data size after outlier removal: {data_clean.shape[0]}")

# 处理标签分布不均
label_counts = data_clean['Label_2'].value_counts()
print("Label distribution before processing:")
print(label_counts)

# 创建新的DataFrame来存储平衡后的数据
balanced_data = pd.DataFrame()
yangbeng = 10000
for label in data_clean['Label_2'].unique():
    class_data = data_clean[data_clean['Label_2'] == label]
    if len(class_data) > yangbeng:
        class_sampled = resample(class_data,
                                 replace=False,
                                 n_samples=yangbeng,
                                 random_state=42)
    else:
        class_sampled = resample(class_data,
                                 replace=True,
                                 n_samples=yangbeng,
                                 random_state=42)
    balanced_data = pd.concat([balanced_data, class_sampled])

# 确保最后的样本数量为500,000
print(f"Final balanced data size: {balanced_data.shape[0]}")

# 打印新的标签分布
print("Label distribution after processing:")
print(balanced_data['Label_2'].value_counts())

# 数据处理
balanced_data = balanced_data.dropna()
print(f"Data shape after dropping NaN values: {balanced_data.shape}")

# 分离特征和标签
X_data = balanced_data.iloc[:, 1:-1].values  # 假设第2列到倒数第2列是特征
y_data = balanced_data['Label_2'].values  # 最后一列标签

# 使用滑动窗口处理数据
window_seconds = 0.8  # 例如窗口大小为5秒
window_overlapping = 0.5  # 例如重叠率为50%
X_windows, y_windows = process_sliding_window(X_data, y_data, window_seconds, window_overlapping)

# 将窗口数据转换为2D（每个窗口为一行）
X_windows_flat = X_windows.reshape(X_windows.shape[0], -1)

# 数据集划分
X_train, X_test, y_train, y_test = train_test_split(X_windows_flat, y_windows, test_size=0.4, random_state=42,
                                                    stratify=y_windows)

# 将标签从1-5转换为0-4
y_train = y_train - 1
y_test = y_test - 1

# 数据标准化
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# 定义和评估各个模型
models = {
    "LightGBM": (LGBMClassifier(random_state=42), {
        'n_estimators': [50, 100, 150],
        'learning_rate': [0.01, 0.1, 0.2],
        'max_depth': [-1, 10, 20]
    }),
    "CatBoost": (CatBoostClassifier(random_state=42, verbose=0), {
        'iterations': [50, 100, 150],
        'learning_rate': [0.01, 0.1, 0.2],
        'depth': [4, 6, 8]
    }),
    "AdaBoost": (AdaBoostClassifier(random_state=42), {
        'n_estimators': [50, 100, 150],
        'learning_rate': [0.01, 0.1, 1.0]
    }),
    "Extra Trees": (ExtraTreesClassifier(random_state=42), {
        'n_estimators': [50, 100, 150],
        'max_depth': [None, 10, 20]
    }),
    "Stacking": (StackingClassifier(estimators=[
        ('lr', LogisticRegression()),
        ('dt', DecisionTreeClassifier()),
        ('svm', SVC())
    ], final_estimator=LogisticRegression()), {
                     'final_estimator__C': [0.1, 1.0, 10]
                 }),
    "Bagging": (BaggingClassifier(random_state=42), {
        'n_estimators': [10, 50, 100]
    }),
    "Elastic Net Logistic Regression": (
        LogisticRegression(penalty='elasticnet', solver='saga', max_iter=1000, random_state=42), {
            'l1_ratio': [0.2, 0.5, 0.8],
            'C': [0.1, 1.0, 10]
        }),
    "SVC": (SVC(random_state=42), {
        'kernel': ['linear', 'rbf'],
        'C': [0.1, 1.0, 10]
    }),
    "RandomForest": (RandomForestClassifier(random_state=42), {
        'n_estimators': [50, 100, 150],
        'max_depth': [None, 10, 20],
        'min_samples_split': [2, 5],
        'min_samples_leaf': [1, 3],
        'max_features': ['sqrt', 'log2']
    }),
    "Logistic": (LogisticRegression(penalty='l2', solver='lbfgs', max_iter=1000, random_state=42), {
        'C': [0.1, 1.0, 10]
    }),
    "XGBoost": (xgb.XGBClassifier(random_state=42), {
        'n_estimators': [50, 100, 150],
        'learning_rate': [0.01, 0.1, 0.2],
        'max_depth': [3, 6, 9],
        'subsample': [0.7, 0.8, 1.0],
        'colsample_bytree': [0.7, 0.8, 1.0]
    })
}

# 初始化字典来存储每个模型的四个分类指标
metrics = {
    "Accuracy": {},
    "Precision": {},
    "Recall": {},
    "F1 Score": {}
}

# 初始化文件来保存最佳参数
best_params_file = os.path.join(config.MODEL_SAVE_DIR, 'best_params.txt')
with open(best_params_file, 'w') as f:
    f.write("Best Parameters for each model:\n\n")

# 训练、调优、评估并保存每个模型
for name, (model, params) in models.items():
    print(f"Optimizing {name}...")

    # 使用 RandomizedSearchCV 进行超参数优化
    randomized_search = RandomizedSearchCV(estimator=model, param_distributions=params, scoring='accuracy', cv=3,
                                           n_jobs=-1, n_iter=10, random_state=42)
    randomized_search.fit(X_train, y_train)

    # 获取最佳模型
    best_model = randomized_search.best_estimator_

    # 保存最佳参数
    with open(best_params_file, 'a') as f:
        f.write(f'{name}: {randomized_search.best_params_}\n')

    # 预测
    y_pred = best_model.predict(X_test)

    # 计算四个分类指标
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, average='weighted')
    recall = recall_score(y_test, y_pred, average='weighted')
    f1 = f1_score(y_test, y_pred, average='weighted')

    # 保存模型
    model_save_path = os.path.join(config.MODEL_SAVE_DIR, f'{name.lower().replace(" ", "_")}_model.pkl')
    joblib.dump(best_model, model_save_path)

    # 保存各项指标
    metrics["Accuracy"][name] = accuracy
    metrics["Precision"][name] = precision
    metrics["Recall"][name] = recall
    metrics["F1 Score"][name] = f1

    # 打印当前模型的测试结果
    print(f'{name} Test Results:')
    print(f'  Accuracy: {accuracy * 100:.2f}%')
    print(f'  Precision: {precision * 100:.2f}%')
    print(f'  Recall: {recall * 100:.2f}%')
    print(f'  F1 Score: {f1 * 100:.2f}%\n')

    # 自定义标签
    labels = ['ST', 'WK', 'TR', 'BD', 'SQ']

    # 打印混淆矩阵
    cm = confusion_matrix(y_test, y_pred)
    cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]

    plt.figure(figsize=(10, 4))

    plt.subplot(1, 2, 1)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=labels, yticklabels=labels)
    plt.title(f'{name} Confusion Matrix')
    plt.xlabel('Predicted')
    plt.ylabel('True')

    plt.subplot(1, 2, 2)
    sns.heatmap(cm_normalized, annot=True, fmt='.2f', cmap='Blues', xticklabels=labels, yticklabels=labels)
    plt.title(f'{name} Normalized Confusion Matrix')
    plt.xlabel('Predicted')
    plt.ylabel('True')

    plt.tight_layout()
    plt.show()

# 对比结果
print("\nModel Comparison:")
for metric, results in metrics.items():
    print(f'\n{metric}:')
    for name, value in results.items():
        print(f'  {name}: {value * 100:.2f}%')
