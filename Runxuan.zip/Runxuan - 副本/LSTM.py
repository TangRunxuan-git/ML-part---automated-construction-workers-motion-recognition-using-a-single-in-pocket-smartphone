import os
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
from sklearn.ensemble import IsolationForest
from sklearn.utils import resample
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
from imblearn.over_sampling import SMOTE

class Config:
    DATA_PATH = r'D:\传感器\data\all_data1.csv'
    DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    BATCH_SIZE = 64
    LEARNING_RATE = 0.001
    NUM_EPOCHS = 30
    MODEL_SAVE_DIR = r'D:\传感器\weight'


config = Config()

def process_sliding_window(X_data, y_data, window_seconds, window_overlapping):
    """
    对数据进行滑动窗口切分，根据所选窗口长度和重叠率。
    参数:
    X_data: 输入特征数据，形状为 (num_samples, num_features)
    y_data: 标签数据，形状为 (num_samples,)
    window_seconds: 滑窗窗口大小，以秒为单位
    window_overlapping: 滑窗的重叠率，范围为 [0, 1)
    返回:
    windows: 切分后的数据，形状为 (num_windows, window_size, num_features)
    labels: 对应的标签，形状为 (num_windows,)
    """
    sample_hz = 50  # 传感器采样频率
    window_size = int(window_seconds * sample_hz)  # 窗口大小（采样点数）
    step_size = int(window_size * (1 - window_overlapping))  # 步长，考虑到窗口重叠率
    windows = []
    labels = []
    i = 0
    while i + window_size <= X_data.shape[0]:  # 遍历数据
        # 确保窗口内数据是连续的，检查时间差
        if (X_data[i + window_size - 1, 0] - X_data[i, 0]) <= 2 * window_seconds * 1e9:
            windows.append(X_data[i:i + window_size, :])
            labels.append(y_data[i + window_size - 1])
            i += step_size  # 移动到下一个窗口
        else:
            i += 1  # 数据不连续，跳到下一个点
    windows = np.array(windows)
    labels = np.array(labels)
    return windows, labels

# %%
# 读取数据
data = pd.read_csv(config.DATA_PATH)

# 使用孤立森林删除离群值
isolation_forest = IsolationForest(contamination=0.01)
outliers = isolation_forest.fit_predict(data.iloc[:, 1:])  # 假设第1列是非数值列
data['outlier'] = outliers

# 过滤掉离群点
data_clean = data[data['outlier'] == 1]
data_clean = data_clean.drop(columns=['outlier'])

# 打印删除前后的样本数量
print(f"Original data size: {data.shape[0]}")
print(f"Data size after outlier removal: {data_clean.shape[0]}")

# %%
# 处理标签分布不均
label_counts = data_clean['Label_2'].value_counts()
print("Label distribution before processing:")
print(label_counts)

# 创建新的DataFrame来存储平衡后的数据
balanced_data = pd.DataFrame()
yangbeng = 100000
# 对每个标签进行下采样或过采样
for label in data_clean['Label_2'].unique():
    class_data = data_clean[data_clean['Label_2'] == label]
    if len(class_data) > yangbeng:
        # 如果样本数量超过100,000，进行下采样
        class_sampled = resample(class_data,
                                 replace=False,
                                 n_samples=yangbeng,
                                 random_state=42)
    else:
        # 如果样本数量少于100,000，进行过采样
        class_sampled = resample(class_data,
                                 replace=True,
                                 n_samples=yangbeng,
                                 random_state=42)

    balanced_data = pd.concat([balanced_data, class_sampled])

# 确保最后的样本数量为500,000
print(f"Final balanced data size: {balanced_data.shape[0]}")

# 打印新的标签分布
print("Label distribution after processing:")
print(balanced_data['Label_2'].value_counts())

# %% 数据处理
# 删除包含缺失值的行
balanced_data = balanced_data.dropna()

# 检查删除缺失值后的数据形状
print(f"Data shape after dropping NaN values: {balanced_data.shape}")

# 分离特征和标签
X_data = balanced_data.iloc[:, 1:-1].values  # 假设第2列到倒数第2列是特征
y_data = balanced_data['Label_2'].values  # 最后一列标签

# 使用滑动窗口处理数据
window_seconds = 0.8  # 例如窗口大小为5秒
window_overlapping = 0.5  # 例如重叠率为50%
X_windows, y_windows = process_sliding_window(X_data, y_data, window_seconds, window_overlapping)

# 将窗口数据转换为2D（每个窗口为一行）
X_windows_flat = X_windows.reshape(X_windows.shape[0], -1)

# 数据集划分
X_train, X_test, y_train, y_test = train_test_split(X_windows_flat, y_windows, test_size=0.4, random_state=42, stratify=y_windows)

# 将标签从1-5转换为0-4
y_train = y_train - 1
y_test = y_test - 1

# 打印标签的最小值和最大值以确认其在正确范围内
print(f"y_train min: {y_train.min()}, max: {y_train.max()}")
print(f"y_test min: {y_test.min()}, max: {y_test.max()}")

# 更新配置中的批次大小，减小内存负担
config.BATCH_SIZE = 32  # 可进一步调整

# 数据标准化
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# 将数据转换为PyTorch张量
X_train = torch.tensor(X_train, dtype=torch.float32)
y_train = torch.tensor(y_train, dtype=torch.long)
X_test = torch.tensor(X_test, dtype=torch.float32)
y_test = torch.tensor(y_test, dtype=torch.long)

# 打印标签的最小值和最大值以确认其在正确范围内
print(f"y_train min: {y_train.min()}, max: {y_train.max()}")
print(f"y_test min: {y_test.min()}, max: {y_test.max()}")


print(f"训练集大小: {X_train.shape[0]}")
print(f"测试集大小: {X_test.shape[0]}")


print('123')
# 创建数据加载器
train_dataset = TensorDataset(X_train, y_train)
test_dataset = TensorDataset(X_test, y_test)
train_loader = DataLoader(train_dataset, batch_size=config.BATCH_SIZE, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=config.BATCH_SIZE, shuffle=False)

'''##########################定义模型######################################'''
# 定义LSTM模型
class LSTMClassifier(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers, output_dim, dropout=0.5):
        super(LSTMClassifier, self).__init__()

        self.hidden_dim = hidden_dim
        self.num_layers = num_layers

        self.lstm = nn.LSTM(input_size=input_dim,
                            hidden_size=hidden_dim,
                            num_layers=num_layers,
                            dropout=dropout,
                            batch_first=True,
                            bidirectional=True)

        self.fc = nn.Linear(2 * hidden_dim, output_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        # 如果输入是二维的，则增加时间步维度以匹配 LSTM 输入要求
        if x.dim() == 2:
            x = x.unsqueeze(1)

        h_0 = torch.zeros(2 * self.num_layers, x.size(0), self.hidden_dim).to(x.device)
        c_0 = torch.zeros(2 * self.num_layers, x.size(0), self.hidden_dim).to(x.device)

        lstm_out, _ = self.lstm(x, (h_0, c_0))
        out = self.fc(lstm_out[:, -1, :])

        return out
'''##########################定义模型######################################'''


'''##########################参数设置######################################'''
input_dim = X_train.shape[1]  # 输入特征数（每个时间步的特征数）
hidden_dim = 64  # GRU隐藏层大小
num_layers = 2  # GRU层数
output_dim = len(np.unique(y_train))  # 类别数量

# 创建模型
model = LSTMClassifier(input_dim, hidden_dim, num_layers, output_dim)
model = model.to(config.DEVICE)

# 定义损失函数和优化器
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=config.LEARNING_RATE, weight_decay=1e-4)

# 学习率调度器
scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=5, verbose=True)

# 提前停止的配置
patience, trials = 10, 0
best_val_loss = float('inf')
'''##########################参数设置######################################'''


'''##########################训练模型######################################'''
train_losses = []
test_losses = []
for epoch in range(config.NUM_EPOCHS):
    model.train()
    running_loss = 0.0
    for X_batch, y_batch in train_loader:
        X_batch, y_batch = X_batch.to(config.DEVICE), y_batch.to(config.DEVICE)

        # 前向传播
        outputs = model(X_batch)
        loss = criterion(outputs, y_batch)

        # 反向传播和优化
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        running_loss += loss.item()

    # 记录训练损失
    train_losses.append(running_loss / len(train_loader))

    # 在测试集上评估并记录测试损失
    model.eval()
    with torch.no_grad():
        test_loss = 0.0
        all_preds = []
        for X_batch, y_batch in test_loader:
            X_batch, y_batch = X_batch.to(config.DEVICE), y_batch.to(config.DEVICE)
            outputs = model(X_batch)
            loss = criterion(outputs, y_batch)
            test_loss += loss.item()
            all_preds.extend(outputs.cpu().numpy())

        test_losses.append(test_loss / len(test_loader))

    print(
        f'Epoch [{epoch + 1}/{config.NUM_EPOCHS}], Train Loss: {train_losses[-1]:.4f}, Test Loss: {test_losses[-1]:.4f}')

    # 调整学习率
    scheduler.step(test_losses[-1])

    # 提前停止
    if test_losses[-1] < best_val_loss:
        best_val_loss = test_losses[-1]
        trials = 0
        # 保存当前最好的模型
        torch.save(model.state_dict(), os.path.join(config.MODEL_SAVE_DIR, 'best_bilstm_cnn_model.pth'))
    else:
        trials += 1
        if trials >= patience:
            print(f"Early stopping on epoch {epoch + 1}")
            break

# 生成模型保存路径
model_save_path = os.path.join(config.MODEL_SAVE_DIR, 'bilstm_cnn_model.pth')

# 保存最终模型参数
torch.save(model.state_dict(), model_save_path)

'''##########################测试模型并计算分类指标######################################'''
# 加载最好的模型
model.load_state_dict(torch.load(os.path.join(config.MODEL_SAVE_DIR, 'best_bilstm_cnn_model.pth')))
model.eval()
all_preds = []
with torch.no_grad():
    for X_batch, y_batch in test_loader:
        X_batch, y_batch = X_batch.to(config.DEVICE), y_batch.to(config.DEVICE)
        outputs = model(X_batch)
        _, predicted = torch.max(outputs.data, 1)
        all_preds.extend(predicted.cpu().numpy())

    accuracy = accuracy_score(y_test.cpu(), all_preds)
    precision = precision_score(y_test.cpu(), all_preds, average='weighted')
    recall = recall_score(y_test.cpu(), all_preds, average='weighted')
    f1 = f1_score(y_test.cpu(), all_preds, average='weighted')
    print(f'\nTest Accuracy: {accuracy * 100:.2f}%')
    print(f'Precision: {precision * 100:.2f}%')
    print(f'Recall: {recall * 100:.2f}%')
    print(f'F1 Score: {f1 * 100:.2f}%')

'''##########################画图部分######################################'''
# 混淆矩阵标签映射
labels = ['ST', 'WK', 'TR', 'BD', 'SQ']

# 混淆矩阵
cm = confusion_matrix(y_test.cpu(), all_preds)
cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
plt.figure(figsize=(10, 4))

# 非归一化混淆矩阵
plt.subplot(1, 2, 1)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=labels, yticklabels=labels)
plt.title('Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('True')

# 归一化混淆矩阵
plt.subplot(1, 2, 2)
sns.heatmap(cm_normalized, annot=True, fmt='.2f', cmap='Blues', xticklabels=labels, yticklabels=labels)
plt.title('Normalized Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('True')
plt.tight_layout()
plt.show()

# 绘制损失曲线
plt.figure(figsize=(10, 5))
plt.plot(range(1, len(train_losses) + 1), train_losses, label='Train Loss')
plt.plot(range(1, len(test_losses) + 1), test_losses, label='Test Loss')
plt.title('Loss Curve')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()
plt.show()
'''##########################画图部分######################################'''
